
public class CardLabel extends javax.swing.JLabel
{

   public int cardId;
   public Card card;
   public boolean almostPut;
}
